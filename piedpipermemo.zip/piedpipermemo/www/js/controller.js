

pp.controller('addmemoController',function($scope,$firebaseArray,$state,memoService) {
  $scope.submitMemo = function(){
  $scope.mems = memoService.all;
    $scope.mems.$add({
      memoTitle : $scope.memoTitle,
      memoBody : $scope.memoBody
    });
    $state.go('home');
  };
});

pp.controller('memlistController',function($scope,memoService){
  $scope.memos = memoService.all;
});

pp.controller('singlememoController',function($scope,memoService,$stateParams,$state){
  $scope.singlememo = memoService.get($stateParams.id);
});
