pp.factory('memoService', function ($firebaseArray) {
    var ppref = new Firebase('https://piedpipermemo.firebaseio.com/');
    var mems = $firebaseArray(ppref);
    var memoService = {
        all: mems,
        get: function (memId) {
            return mems.$getRecord(memId);
        }
    };
  return memoService;
});
